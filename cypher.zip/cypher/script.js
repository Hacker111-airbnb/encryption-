document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const messageInput = document.getElementById('message');
    const shiftInput = document.getElementById('shift');
    const resultDiv = document.getElementById('result');
    const processBtn = document.getElementById('process-btn');
    const copyBtn = document.getElementById('copy-btn');
    const modeBtns = document.querySelectorAll('.mode-btn');
    const decreaseShiftBtn = document.getElementById('decrease-shift');
    const increaseShiftBtn = document.getElementById('increase-shift');
    const historyList = document.getElementById('history-list');

    // Current mode (encrypt/decrypt)
    let currentMode = 'encrypt';
    let history = JSON.parse(localStorage.getItem('cipherHistory')) || [];

    // Initialize the app
    function init() {
        renderHistory();
        
        // Set mode buttons event listeners
        modeBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                modeBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                currentMode = this.dataset.mode;
                processBtn.innerHTML = currentMode === 'encrypt' 
                    ? '<i class="fas fa-lock"></i> Encrypt' 
                    : '<i class="fas fa-lock-open"></i> Decrypt';
            });
        });

        // Process button click
        processBtn.addEventListener('click', processMessage);

        // Copy button click
        copyBtn.addEventListener('click', copyResult);

        // Shift controls
        decreaseShiftBtn.addEventListener('click', () => adjustShift(-1));
        increaseShiftBtn.addEventListener('click', () => adjustShift(1));
    }

    // Caesar Cipher function
    function caesarCipher(text, shift, mode) {
        let result = "";
        
        if (mode === 'decrypt') {
            shift = -shift;
        }
        
        for (let char of text) {
            if (char.match(/[a-z]/i)) {
                const code = char.charCodeAt(0);
                const offset = code >= 65 && code <= 90 ? 65 : 97;
                result += String.fromCharCode(((code - offset + shift + 26) % 26) + offset);
            } else {
                result += char;
            }
        }
        return result;
    }

    // Process the message
    function processMessage() {
        const message = messageInput.value.trim();
        const shift = parseInt(shiftInput.value);
        
        if (!message) {
            alert('Please enter a message');
            return;
        }
        
        if (isNaN(shift) || shift < 1 || shift > 25) {
            alert('Shift must be a number between 1 and 25');
            return;
        }
        
        const processedText = caesarCipher(message, shift, currentMode);
        resultDiv.textContent = processedText;
        
        // Add to history
        addToHistory(message, processedText, shift, currentMode);
    }

    // Copy result to clipboard
    function copyResult() {
        if (!resultDiv.textContent) {
            alert('No result to copy');
            return;
        }
        
        navigator.clipboard.writeText(resultDiv.textContent)
            .then(() => {
                copyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                setTimeout(() => {
                    copyBtn.innerHTML = '<i class="far fa-copy"></i> Copy to Clipboard';
                }, 2000);
            })
            .catch(err => {
                console.error('Failed to copy: ', err);
                alert('Failed to copy text');
            });
    }

    // Adjust shift value
    function adjustShift(change) {
        let newShift = parseInt(shiftInput.value) + change;
        if (newShift < 1) newShift = 25;
        if (newShift > 25) newShift = 1;
        shiftInput.value = newShift;
    }

    // Add item to history
    function addToHistory(original, processed, shift, mode) {
        const timestamp = new Date().toLocaleString();
        const historyItem = {
            id: Date.now(),
            original,
            processed,
            shift,
            mode,
            timestamp
        };
        
        history.unshift(historyItem);
        if (history.length > 10) history.pop();
        
        localStorage.setItem('cipherHistory', JSON.stringify(history));
        renderHistory();
    }

    // Render history
    function renderHistory() {
        historyList.innerHTML = '';
        
        if (history.length === 0) {
            historyList.innerHTML = '<p class="empty-history">No history yet</p>';
            return;
        }
        
        history.forEach(item => {
            const historyItem = document.createElement('div');
            historyItem.className = 'history-item';
            historyItem.innerHTML = `
                <div class="content">
                    <strong>${item.mode === 'encrypt' ? 'Encrypted' : 'Decrypted'}</strong> with shift ${item.shift}
                    <div class="timestamp">${item.timestamp}</div>
                </div>
                <div class="actions">
                    <button class="view-btn" data-id="${item.id}" title="View">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="delete-btn" data-id="${item.id}" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            
            historyList.appendChild(historyItem);
        });
        
        // Add event listeners to history buttons
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', () => viewHistoryItem(btn.dataset.id));
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', () => deleteHistoryItem(btn.dataset.id));
        });
    }

    // View history item
    function viewHistoryItem(id) {
        const item = history.find(i => i.id === parseInt(id));
        if (item) {
            messageInput.value = item.original;
            shiftInput.value = item.shift;
            
            // Set the correct mode
            modeBtns.forEach(btn => btn.classList.remove('active'));
            const modeBtn = document.querySelector(`.mode-btn[data-mode="${item.mode}"]`);
            if (modeBtn) {
                modeBtn.classList.add('active');
                currentMode = item.mode;
                processBtn.innerHTML = currentMode === 'encrypt' 
                    ? '<i class="fas fa-lock"></i> Encrypt' 
                    : '<i class="fas fa-lock-open"></i> Decrypt';
            }
            
            // Process and show result
            resultDiv.textContent = item.processed;
        }
    }

    // Delete history item
    function deleteHistoryItem(id) {
        history = history.filter(i => i.id !== parseInt(id));
        localStorage.setItem('cipherHistory', JSON.stringify(history));
        renderHistory();
    }

    // Initialize the app
    init();
});